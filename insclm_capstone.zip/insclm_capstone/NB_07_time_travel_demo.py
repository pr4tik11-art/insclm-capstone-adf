# Databricks notebook source
# MAGIC %run /Workspace/Users/updazvmnag_1777788725142@npupgradassessment.onmicrosoft.com/insclm_capstone/NB_00_config_loader

# COMMAND ----------

from pyspark.sql import functions as F
from delta.tables import DeltaTable

# Force ADLS config for job context
spark.conf.set(
    "fs.azure.account.key.stinsclmcap11.dfs.core.windows.net",
    dbutils.secrets.get("kv-insclm", "adls-account-key")
)

POLICY_DIM_PATH   = SILVER_PATH + "/policy_dim"
CLAIMS_FACT_PATH  = SILVER_PATH + "/claims_fact"
GOLD_SUMMARY_PATH = GOLD_PATH   + "/claim_summary"

print("=" * 55)
print("DELTA LAKE TIME TRAVEL DEMONSTRATION")
print("=" * 55)

# COMMAND ----------

print("\n📋 Full history of silver/policy_dim:")

DeltaTable.forPath(spark, POLICY_DIM_PATH) \
    .history() \
    .select(
        "version",
        "timestamp",
        "operation",
        "operationMetrics"
    ).show(10, truncate=False)

# COMMAND ----------

print("\n📋 Time Travel — by VERSION number")
print("   Reading version 0 = first load\n")

v0_df = spark.read \
    .format("delta") \
    .option("versionAsOf", 0) \
    .load(POLICY_DIM_PATH)

v0_count      = v0_df.count()
current_count = spark.read.format("delta") \
    .load(POLICY_DIM_PATH).count()

print(f"   Version 0 row count : {v0_count:,}")
print(f"   Current row count   : {current_count:,}")
print(f"   Difference          : {current_count - v0_count:,}")

print("\nSample rows from Version 0:")
v0_df.select(
    "policy_id","policy_type",
    "policy_status","coverage_amount","is_current"
).show(5, truncate=False)

# COMMAND ----------

print("\n📋 Time Travel — by TIMESTAMP\n")

history_df = DeltaTable.forPath(
    spark, POLICY_DIM_PATH).history()

earliest_ts = history_df.agg(
    F.min("timestamp")).first()[0]

print(f"   Earliest version timestamp: {earliest_ts}")

try:
    ts_df = spark.read \
        .format("delta") \
        .option("timestampAsOf", str(earliest_ts)) \
        .load(POLICY_DIM_PATH)

    print(f"   Rows at earliest version: {ts_df.count():,}")
    ts_df.select(
        "policy_id","policy_status",
        "coverage_amount","is_current"
    ).show(5, truncate=False)

except Exception as e:
    print(f"   Note: {e}")

# COMMAND ----------

print("\n📋 Policy status at claim date vs current status\n")

current_policy = (spark.read.format("delta")
    .load(POLICY_DIM_PATH)
    .filter(F.col("is_current") == True)
    .select(
        "policy_id",
        F.col("policy_status").alias("current_status"),
        F.col("coverage_amount").alias("current_coverage")
    ))

claims_snapshot = (spark.read.format("delta")
    .load(CLAIMS_FACT_PATH)
    .select(
        "claim_id","policy_id",
        "claim_date",
        "policy_status_at_claim",
        "claim_amount"
    ).distinct())

comparison = (claims_snapshot
    .join(current_policy,"policy_id","left")
    .withColumn("status_changed",
        F.col("policy_status_at_claim") !=
        F.col("current_status")))

total         = comparison.count()
changed_count = comparison.filter(
    F.col("status_changed")==True).count()
unchanged     = total - changed_count

print(f"   Total claims compared     : {total:,}")
print(f"   Status same as today      : {unchanged:,}")
print(f"   Status changed since claim: {changed_count:,}")

if changed_count > 0:
    print("\nSample — policies changed after claim:")
    comparison \
        .filter(F.col("status_changed")==True) \
        .select(
            "claim_id","policy_id","claim_date",
            "policy_status_at_claim","current_status"
        ).show(10, truncate=False)
else:
    print("\nNo policy status changes detected")

# COMMAND ----------

print("\n📋 Delta history of silver/claims_fact:")
DeltaTable.forPath(spark, CLAIMS_FACT_PATH) \
    .history() \
    .select("version","timestamp",
            "operation","operationMetrics") \
    .show(5, truncate=False)

print("\n📋 Delta history of gold/claim_summary:")
DeltaTable.forPath(spark, GOLD_SUMMARY_PATH) \
    .history() \
    .select("version","timestamp",
            "operation","operationMetrics") \
    .show(5, truncate=False)

# COMMAND ----------

print("\n" + "=" * 55)
print("TIME TRAVEL SUMMARY")
print("=" * 55)
print("✅ DESCRIBE HISTORY — silver/policy_dim")
print("✅ Time Travel by version — demonstrated")
print("✅ Time Travel by timestamp — demonstrated")
print("✅ Policy status at claim date — compared")
print("✅ DESCRIBE HISTORY — silver/claims_fact")
print("✅ DESCRIBE HISTORY — gold/claim_summary")
print("=" * 55)
print("✅ NB_07 complete.")
print("   Next: Run NB_08_describe_history_optimize")