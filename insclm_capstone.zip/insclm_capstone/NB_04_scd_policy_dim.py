# Databricks notebook source
# MAGIC %run /Workspace/Users/updazvmnag_1777788725142@npupgradassessment.onmicrosoft.com/insclm_capstone/NB_00_config_loader

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
from delta.tables import DeltaTable
from datetime import datetime

# Force ADLS config for job context
spark.conf.set(
    "fs.azure.account.key.stinsclmcap11.dfs.core.windows.net",
    dbutils.secrets.get("kv-insclm", "adls-account-key")
)

def path_exists(path):
    try:
        dbutils.fs.ls(path)
        return True
    except:
        return False

print("✅ Imports done")

# COMMAND ----------

print("\n📥 Loading bronze/policy_master...")
bronze_policy = spark.read.format("delta") \
    .load(BRONZE_PATH + "/policy_master")
print(f"   Rows: {bronze_policy.count():,}  (expected 1,500)")

# COMMAND ----------

SCD_COLS = ["policy_type","coverage_amount",
            "premium_amount","policy_status"]

hash_expr = F.md5(F.concat_ws("||",
    *[F.col(c).cast("string") for c in SCD_COLS]))

source_df = (bronze_policy
    .withColumn("record_hash",    hash_expr)
    .withColumn("effective_date", F.col("last_updated"))
    .withColumn("expiry_date",
        F.lit("9999-12-31 00:00:00")
         .cast(TimestampType()))
    .withColumn("is_current",     F.lit(True))
    .withColumn("created_at",     F.current_timestamp())
    .withColumn("updated_at",     F.current_timestamp()))

print(f"✅ Source dataframe ready: {source_df.count():,} rows")

# COMMAND ----------

POLICY_DIM_PATH = SILVER_PATH + "/policy_dim"

if not path_exists(POLICY_DIM_PATH + "/_delta_log"):
    print("\n📥 Initial SCD load...")

    initial_df = (source_df
        .withColumn("policy_sk",
            F.monotonically_increasing_id())
        .select(
            "policy_sk","policy_id","customer_id",
            "policy_type","coverage_amount",
            "premium_amount","policy_status",
            "start_date","end_date",
            "effective_date","expiry_date",
            "is_current","record_hash",
            "created_at","updated_at"))

    initial_df.write \
        .format("delta").mode("overwrite") \
        .option("overwriteSchema","true") \
        .save(POLICY_DIM_PATH)

    count = spark.read.format("delta") \
        .load(POLICY_DIM_PATH).count()
    print(f"✅ silver/policy_dim → {count:,} rows")

else:
    print("\n📥 Table exists — SCD MERGE...")
    target       = DeltaTable.forPath(spark, POLICY_DIM_PATH)
    target_df    = target.toDF()
    current_rows = target_df.filter(
        F.col("is_current") == True)

    changed = (source_df.alias("s")
        .join(current_rows.alias("t"),
              "policy_id","inner")
        .filter(F.col("s.record_hash") !=
                F.col("t.record_hash"))
        .select(F.col("s.policy_id")))

    changed_count = changed.count()
    print(f"   Changed policies: {changed_count:,}")

    if changed_count > 0:
        (target.alias("t")
            .merge(changed.alias("c"),
                "t.policy_id = c.policy_id "
                "AND t.is_current = true")
            .whenMatchedUpdate(set={
                "is_current":  "false",
                "expiry_date": "current_timestamp()",
                "updated_at":  "current_timestamp()"
            }).execute())

        max_sk = target_df.agg(
            F.max("policy_sk")).first()[0] or 0

        new_versions = (source_df
            .join(changed,"policy_id","inner")
            .withColumn("policy_sk",
                F.monotonically_increasing_id() +
                F.lit(max_sk + 1))
            .select(
                "policy_sk","policy_id","customer_id",
                "policy_type","coverage_amount",
                "premium_amount","policy_status",
                "start_date","end_date",
                "effective_date","expiry_date",
                "is_current","record_hash",
                "created_at","updated_at"))

        new_versions.write \
            .format("delta").mode("append") \
            .save(POLICY_DIM_PATH)

        print(f"✅ {new_versions.count():,} new rows inserted")
    else:
        print("   No changes — policy_dim up to date")

# COMMAND ----------

policy_dim = spark.read.format("delta") \
    .load(POLICY_DIM_PATH)

total      = policy_dim.count()
current    = policy_dim.filter(
    F.col("is_current") == True).count()
historical = policy_dim.filter(
    F.col("is_current") == False).count()

print("\n" + "=" * 55)
print("SCD TYPE 2 VERIFICATION")
print("=" * 55)
print(f"Total rows      : {total:,}")
print(f"Current rows    : {current:,}  (expected 1,500)")
print(f"Historical rows : {historical:,}")

dupes = (policy_dim
    .filter(F.col("is_current") == True)
    .groupBy("policy_id").count()
    .filter(F.col("count") > 1).count())
print(f"Duplicate check : {dupes}  (expected 0)")

if dupes == 0:
    print("✅ SCD integrity passed")
    print("\n   Go back to NB_02 → run Cells 5, 6, 7")
else:
    print("❌ Duplicate rows — investigate!")

policy_dim.select(
    "policy_id","policy_type","coverage_amount",
    "policy_status","effective_date",
    "expiry_date","is_current","policy_sk"
).orderBy("policy_id").show(5, truncate=False)

# COMMAND ----------

