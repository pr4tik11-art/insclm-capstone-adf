# Databricks notebook source
# MAGIC %run /Workspace/Users/updazvmnag_1777788725142@npupgradassessment.onmicrosoft.com/insclm_capstone/NB_00_config_loader

# COMMAND ----------

from pyspark.sql import functions as F

# Force ADLS config for job context
spark.conf.set(
    "fs.azure.account.key.stinsclmcap11.dfs.core.windows.net",
    dbutils.secrets.get("kv-insclm", "adls-account-key")
)

print("=" * 55)
print("REJECTED RECORDS — STATUS / POLICY / CUSTOMER")
print("=" * 55)

# COMMAND ----------

bronze_status = spark.read.format("delta") \
    .load(BRONZE_PATH + "/claim_status_updates")
print(f"Status updates total: {bronze_status.count():,}")

rejected_status = (bronze_status
    .filter(
        F.col("status_update_id").isNull() |
        F.col("claim_id").isNull()         |
        F.col("new_status").isNull()       |
        F.col("old_status").isNull()       |
        F.col("status_date").isNull())
    .withColumn("rejection_reason",
        F.when(F.col("status_update_id").isNull(),
               "MISSING_STATUS_UPDATE_ID")
        .when(F.col("claim_id").isNull(),
               "MISSING_CLAIM_ID")
        .when(F.col("new_status").isNull(),
               "MISSING_NEW_STATUS")
        .when(F.col("old_status").isNull(),
               "MISSING_OLD_STATUS")
        .when(F.col("status_date").isNull(),
               "MISSING_STATUS_DATE")
        .otherwise("UNKNOWN"))
    .withColumn("rejected_at", F.current_timestamp()))

rejected_status.write \
    .format("delta").mode("overwrite") \
    .option("overwriteSchema","true") \
    .save(REJECTED_PATH + "/status_updates")

s = rejected_status.count()
print(f"✅ rejected/status_updates → {s:,}  (expected 0)")

# COMMAND ----------

bronze_policy = spark.read.format("delta") \
    .load(BRONZE_PATH + "/policy_master")
print(f"\nPolicy master total: {bronze_policy.count():,}")

rejected_policy = (bronze_policy
    .filter(
        F.col("policy_id").isNull()       |
        F.col("customer_id").isNull()     |
        F.col("coverage_amount").isNull() |
        (F.col("coverage_amount") <= 0)   |
        F.col("policy_status").isNull())
    .withColumn("rejection_reason",
        F.when(F.col("policy_id").isNull(),
               "MISSING_POLICY_ID")
        .when(F.col("customer_id").isNull(),
               "MISSING_CUSTOMER_ID")
        .when(F.col("coverage_amount").isNull() |
              (F.col("coverage_amount") <= 0),
               "INVALID_COVERAGE_AMOUNT")
        .when(F.col("policy_status").isNull(),
               "MISSING_POLICY_STATUS")
        .otherwise("UNKNOWN"))
    .withColumn("rejected_at", F.current_timestamp()))

rejected_policy.write \
    .format("delta").mode("overwrite") \
    .option("overwriteSchema","true") \
    .save(REJECTED_PATH + "/policy")

p = rejected_policy.count()
print(f"✅ rejected/policy → {p:,}  (expected 0)")

# COMMAND ----------

bronze_customer = spark.read.format("delta") \
    .load(BRONZE_PATH + "/customer_master")
print(f"\nCustomer master total: {bronze_customer.count():,}")

rejected_customer = (bronze_customer
    .filter(
        F.col("customer_id").isNull()   |
        F.col("customer_name").isNull() |
        F.col("email").isNull()         |
        F.col("phone").isNull()         |
        F.col("risk_category").isNull())
    .withColumn("rejection_reason",
        F.when(F.col("customer_id").isNull(),
               "MISSING_CUSTOMER_ID")
        .when(F.col("customer_name").isNull(),
               "MISSING_CUSTOMER_NAME")
        .when(F.col("email").isNull(),
               "MISSING_EMAIL")
        .when(F.col("phone").isNull(),
               "MISSING_PHONE")
        .when(F.col("risk_category").isNull(),
               "MISSING_RISK_CATEGORY")
        .otherwise("UNKNOWN"))
    .withColumn("rejected_at", F.current_timestamp()))

rejected_customer.write \
    .format("delta").mode("overwrite") \
    .option("overwriteSchema","true") \
    .save(REJECTED_PATH + "/customers")

cu = rejected_customer.count()
print(f"✅ rejected/customers → {cu:,}  (expected 0)")

# COMMAND ----------

print("\n" + "=" * 55)
print("REJECTED RECORDS SUMMARY")
print("=" * 55)
print(f"rejected/claims         : 120 rows (from NB_02)")
print(f"rejected/status_updates : {s:,}  (expected 0)")
print(f"rejected/policy         : {p:,}  (expected 0)")
print(f"rejected/customers      : {cu:,}  (expected 0)")
print("=" * 55)

if s==0 and p==0 and cu==0:
    print("✅ All clean — data quality confirmed")
    print("\n   Next: Run NB_05_merge_claim_status")
else:
    print("⚠️  Unexpected rejections — investigate above")