# Databricks notebook source
# MAGIC %run /Workspace/Users/updazvmnag_1777788725142@npupgradassessment.onmicrosoft.com/insclm_capstone/NB_00_config_loader

# COMMAND ----------

from pyspark.sql import functions as F
from delta.tables import DeltaTable
from datetime import datetime

# Force ADLS config for job context
spark.conf.set(
    "fs.azure.account.key.stinsclmcap11.dfs.core.windows.net",
    dbutils.secrets.get("kv-insclm", "adls-account-key")
)

PATHS = {
    "bronze/claims":
        BRONZE_PATH + "/claims",
    "bronze/claim_status_updates":
        BRONZE_PATH + "/claim_status_updates",
    "bronze/policy_master":
        BRONZE_PATH + "/policy_master",
    "bronze/customer_master":
        BRONZE_PATH + "/customer_master",
    "silver/claims_fact":
        SILVER_PATH + "/claims_fact",
    "silver/customer_dim":
        SILVER_PATH + "/customer_dim",
    "silver/policy_dim":
        SILVER_PATH + "/policy_dim",
    "silver/claim_status_history":
        SILVER_PATH + "/claim_status_history",
    "gold/claim_summary":
        GOLD_PATH + "/claim_summary",
    "gold/policy_history_summary":
        GOLD_PATH + "/policy_history_summary",
    "gold/suspicious_claim_summary":
        GOLD_PATH + "/suspicious_claim_summary",
    "rejected/claims":
        REJECTED_PATH + "/claims",
    "rejected/status_updates":
        REJECTED_PATH + "/status_updates",
    "rejected/policy":
        REJECTED_PATH + "/policy",
    "rejected/customers":
        REJECTED_PATH + "/customers",
}

print("=" * 55)
print("DESCRIBE HISTORY + OPTIMIZE + VACUUM NOTE")
print("=" * 55)
print(f"✅ {len(PATHS)} paths configured")

# COMMAND ----------

print("\n📋 DESCRIBE HISTORY — all tables\n")

for name, path in PATHS.items():
    try:
        print(f"\n{'='*55}")
        print(f"PATH: lakehouse/{name}")
        print(f"{'='*55}")
        DeltaTable.forPath(spark, path) \
            .history() \
            .select(
                "version",
                "timestamp",
                "operation",
                "operationMetrics"
            ).show(3, truncate=False)
    except Exception as e:
        print(f"⚠️  {name}: {e}")

# COMMAND ----------

print("\n" + "=" * 55)
print("OPTIMIZE — compacting small files")
print("=" * 55)

optimize_paths = [
    ("silver/claims_fact",
     SILVER_PATH + "/claims_fact"),
    ("silver/policy_dim",
     SILVER_PATH + "/policy_dim"),
    ("silver/claim_status_history",
     SILVER_PATH + "/claim_status_history"),
    ("gold/claim_summary",
     GOLD_PATH + "/claim_summary"),
    ("gold/suspicious_claim_summary",
     GOLD_PATH + "/suspicious_claim_summary"),
]

for name, path in optimize_paths:
    try:
        start = datetime.now()
        print(f"📥 Optimizing lakehouse/{name}...")
        spark.sql(f"OPTIMIZE delta.`{path}`")
        end = datetime.now()
        print(f"✅ Done in {(end-start).seconds}s")
    except Exception as e:
        print(f"⚠️  {name}: {e}")

# COMMAND ----------

print("\n📋 Table details after OPTIMIZE:")

detail_paths = [
    ("silver/claims_fact",
     SILVER_PATH + "/claims_fact"),
    ("silver/policy_dim",
     SILVER_PATH + "/policy_dim"),
    ("gold/claim_summary",
     GOLD_PATH + "/claim_summary"),
]

for name, path in detail_paths:
    try:
        print(f"\nlakehouse/{name}:")
        spark.sql(f"DESCRIBE DETAIL delta.`{path}`") \
            .select("numFiles","sizeInBytes","location") \
            .show(truncate=False)
    except Exception as e:
        print(f"⚠️  {name}: {e}")

# COMMAND ----------

print("\n📥 Setting retention 730 days on key tables...")

retention_paths = [
    SILVER_PATH + "/policy_dim",
    SILVER_PATH + "/claims_fact",
    SILVER_PATH + "/claim_status_history",
    GOLD_PATH   + "/suspicious_claim_summary",
]

for path in retention_paths:
    try:
        spark.sql(f"""
            ALTER TABLE delta.`{path}`
            SET TBLPROPERTIES (
                'delta.deletedFileRetentionDuration'
                    = 'interval 730 days',
                'delta.logRetentionDuration'
                    = 'interval 730 days'
            )
        """)
        name = path.split("/")[-2] + "/" + path.split("/")[-1]
        print(f"✅ {name} → retention 730 days")
    except Exception as e:
        print(f"⚠️  {path}: {e}")

# COMMAND ----------

print("\n" + "=" * 55)
print("VACUUM — WHY WE DO NOT RUN IT")
print("=" * 55)

vacuum_explanation = """
WHAT IS VACUUM?
    Permanently deletes old Parquet files older
    than the retention period (default 7 days).
    Once deleted — CANNOT be recovered.

WHY VACUUM IS DANGEROUS IN INSURANCE:

    1. REGULATORY COMPLIANCE
       IRDAI requires insurance records preserved
       for minimum 5-10 years. VACUUM destroys
       old Delta versions — compliance impossible.

    2. TIME TRAVEL IS LOST
       After VACUUM, AS OF queries fail because
       old files no longer exist.

    3. SCD TYPE 2 AUDIT TRAIL DESTROYED
       policy_dim MERGE history proves WHEN
       policies changed. VACUUM removes evidence.

    4. FRAUD INVESTIGATION
       Investigators need original claim values
       from filing date. VACUUM destroys this.

    5. NO RECOVERY
       VACUUM is permanent — no rollback.

SAFE APPROACH:
    Retention set to 730 days minimum.
    Use ADLS lifecycle policies for cost savings.

    If absolutely required — always DRY RUN first:
    VACUUM delta.`/path/` RETAIN 17520 HOURS DRY RUN

BOTTOM LINE:
    VACUUM is NOT run on this dataset.
    All Delta history preserved for compliance.
"""
print(vacuum_explanation)

# COMMAND ----------

print("\n" + "=" * 55)
print("SUMMARY")
print("=" * 55)
print(f"✅ DESCRIBE HISTORY — {len(PATHS)} tables inspected")
print("✅ OPTIMIZE — 5 tables compacted")
print("✅ DESCRIBE DETAIL — file counts verified")
print("✅ Retention — 730 days set on 4 tables")
print("✅ VACUUM — documented, NOT executed")
print("=" * 55)
print("✅ NB_08 complete.")
print("   Next: Run NB_09_load_to_azure_sql")

# COMMAND ----------

# Check what paths are being used
print(f"BRONZE_PATH : {BRONZE_PATH}")
print(f"SILVER_PATH : {SILVER_PATH}")
print(f"GOLD_PATH   : {GOLD_PATH}")
print(f"RAW_PATH    : {RAW_PATH}")