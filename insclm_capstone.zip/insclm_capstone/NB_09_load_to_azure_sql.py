# Databricks notebook source
# MAGIC %run /Workspace/Users/updazvmnag_1777788725142@npupgradassessment.onmicrosoft.com/insclm_capstone/NB_00_config_loader

# COMMAND ----------

from pyspark.sql import functions as F
from datetime import datetime

# Force ADLS config for job context
spark.conf.set(
    "fs.azure.account.key.stinsclmcap11.dfs.core.windows.net",
    dbutils.secrets.get("kv-insclm", "adls-account-key")
)

print("=" * 55)
print("LOADING GOLD TABLES TO AZURE SQL")
print("=" * 55)

connection_properties = {
    "user":     SQL_USER,
    "password": SQL_PASSWORD,
    "driver":   "com.microsoft.sqlserver.jdbc.SQLServerDriver"
}

print("✅ JDBC connection properties ready")

# COMMAND ----------

from pyspark.sql import functions as F
from datetime import datetime

print("=" * 55)
print("LOADING GOLD TABLES TO AZURE SQL")
print("=" * 55)

connection_properties = {
    "user":     SQL_USER,
    "password": SQL_PASSWORD,
    "driver":   "com.microsoft.sqlserver.jdbc.SQLServerDriver"
}

print("✅ JDBC connection properties ready")

# COMMAND ----------

def write_to_sql(df, table_name, mode="overwrite"):
    start     = datetime.now()
    row_count = df.count()
    print(f"\n📥 Writing {row_count:,} rows to {table_name}...")

    df.write \
        .format("jdbc") \
        .option("url",      SQL_JDBC_URL) \
        .option("dbtable",  table_name) \
        .option("user",     SQL_USER) \
        .option("password", SQL_PASSWORD) \
        .option("driver",
            "com.microsoft.sqlserver.jdbc.SQLServerDriver") \
        .option("batchsize", 10000) \
        .mode(mode) \
        .save()

    end = datetime.now()
    print(f"✅ {table_name} → {row_count:,} rows "
          f"in {(end-start).seconds}s")
    return row_count

def read_from_sql(query):
    return spark.read \
        .format("jdbc") \
        .option("url",      SQL_JDBC_URL) \
        .option("query",    query) \
        .option("user",     SQL_USER) \
        .option("password", SQL_PASSWORD) \
        .option("driver",
            "com.microsoft.sqlserver.jdbc.SQLServerDriver") \
        .load()

print("✅ Helper functions ready")

# COMMAND ----------

print("\n── Table 1: reporting.fact_claim_summary ────────")

fact_claim = spark.read.format("delta") \
    .load(GOLD_PATH + "/claim_summary") \
    .withColumn("loaded_at", F.current_timestamp()) \
    .drop("_gold_loaded_at")

c1 = write_to_sql(fact_claim,
                  "reporting.fact_claim_summary")

# COMMAND ----------

print("\n── Table 2: reporting.fact_suspicious_claims ────")

fact_suspicious = spark.read.format("delta") \
    .load(GOLD_PATH + "/suspicious_claim_summary") \
    .select(
        "claim_id","policy_id","customer_id",
        "customer_name","state","risk_category",
        "claim_amount","coverage_amount",
        "policy_status_at_claim","document_status",
        "claim_reason","claim_date",
        "customer_claim_count","suspicious_score",
        "suspicion_level","final_status",
        "final_status_date") \
    .withColumn("loaded_at", F.current_timestamp())

c2 = write_to_sql(fact_suspicious,
                  "reporting.fact_suspicious_claims")

# COMMAND ----------

print("\n── Table 3: reporting.dim_policy_history ────────")

dim_policy = spark.read.format("delta") \
    .load(SILVER_PATH + "/policy_dim") \
    .select(
        "policy_sk","policy_id","customer_id",
        "policy_type","coverage_amount",
        "premium_amount","policy_status",
        "start_date","end_date",
        "effective_date","expiry_date",
        "is_current","record_hash") \
    .withColumn("loaded_at", F.current_timestamp())

c3 = write_to_sql(dim_policy,
                  "reporting.dim_policy_history")

# COMMAND ----------

print("\n" + "=" * 55)
print("VERIFYING ROW COUNTS IN AZURE SQL")
print("=" * 55)

v1 = read_from_sql(
    "SELECT COUNT(*) AS cnt "
    "FROM reporting.fact_claim_summary") \
    .first()["cnt"]

v2 = read_from_sql(
    "SELECT COUNT(*) AS cnt "
    "FROM reporting.fact_suspicious_claims") \
    .first()["cnt"]

v3 = read_from_sql(
    "SELECT COUNT(*) AS cnt "
    "FROM reporting.dim_policy_history") \
    .first()["cnt"]

print(f"fact_claim_summary     : {v1:,}  (written {c1:,})")
print(f"fact_suspicious_claims : {v2:,}  (written {c2:,})")
print(f"dim_policy_history     : {v3:,}  (written {c3:,})")

all_match = (v1==c1 and v2==c2 and v3==c3)
if all_match:
    print("\n✅ All counts match!")
else:
    print("\n❌ Count mismatch — investigate")

# COMMAND ----------

print("\n" + "=" * 55)
print("ANALYTICAL QUERY 1")
print("Approval and Rejection Rate by Policy Type")
print("=" * 55)

result1 = read_from_sql("""
    SELECT
        policy_type,
        SUM(total_claims)             AS total_claims,
        SUM(approved_claims)          AS total_approved,
        SUM(rejected_claims)          AS total_rejected,
        SUM(pending_claims)           AS total_pending,
        ROUND(AVG(approval_rate_pct), 2)
                                      AS avg_approval_rate,
        ROUND(AVG(rejection_rate_pct), 2)
                                      AS avg_rejection_rate,
        ROUND(SUM(total_claim_amount), 2)
                                      AS total_amount
    FROM reporting.fact_claim_summary
    GROUP BY policy_type
""")

result1.orderBy("total_claims", ascending=False) \
    .show(truncate=False)

# COMMAND ----------

print("\n" + "=" * 55)
print("ANALYTICAL QUERY 2")
print("Top 10 High-Risk States by Suspicious Claims")
print("=" * 55)

result2 = read_from_sql("""
    SELECT TOP 10
        state,
        COUNT(*)                     AS total_suspicious,
        COUNT(DISTINCT customer_id)  AS unique_customers,
        ROUND(SUM(claim_amount), 2)  AS total_amount,
        ROUND(AVG(CAST(suspicious_score AS FLOAT)), 2)
                                     AS avg_score,
        SUM(CASE WHEN suspicion_level = 'HIGH'
                 THEN 1 ELSE 0 END)  AS high_risk,
        SUM(CASE WHEN suspicion_level = 'MEDIUM'
                 THEN 1 ELSE 0 END)  AS medium_risk,
        SUM(CASE WHEN suspicion_level = 'LOW'
                 THEN 1 ELSE 0 END)  AS low_risk
    FROM reporting.fact_suspicious_claims
    GROUP BY state
    ORDER BY total_suspicious DESC
""")

result2.show(truncate=False)

# COMMAND ----------

print("\n" + "=" * 55)
print("ANALYTICAL QUERY 3")
print("Top 10 Customers by Suspicious Claim Amount")
print("=" * 55)

result3 = read_from_sql("""
    SELECT TOP 10
        customer_id,
        customer_name,
        state,
        risk_category,
        COUNT(DISTINCT claim_id)
            AS total_suspicious_claims,
        ROUND(SUM(claim_amount), 2)
            AS total_suspicious_amount,
        MAX(customer_claim_count)
            AS overall_claim_count,
        MAX(suspicious_score)
            AS max_suspicious_score,
        SUM(CASE WHEN suspicion_level = 'HIGH'
                 THEN 1 ELSE 0 END)
            AS high_risk_claims
    FROM reporting.fact_suspicious_claims
    GROUP BY
        customer_id, customer_name,
        state, risk_category
    ORDER BY total_suspicious_amount DESC
""")

result3.show(truncate=False)

# COMMAND ----------

print("\n" + "=" * 55)
print("AZURE SQL REPORTING SUMMARY")
print("=" * 55)
print(f"reporting.fact_claim_summary     : {v1:,} rows ✅")
print(f"reporting.fact_suspicious_claims : {v2:,} rows ✅")
print(f"reporting.dim_policy_history     : {v3:,} rows ✅")
print("\n3 Analytical Queries executed ✅")
print("=" * 55)
print("✅ NB_09 complete.")
print("   Next: Run NB_10_audit_logger")