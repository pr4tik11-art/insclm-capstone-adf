# Databricks notebook source
# MAGIC %run /Workspace/Users/updazvmnag_1777788725142@npupgradassessment.onmicrosoft.com/insclm_capstone/NB_00_config_loader

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, lit
from pyspark.sql import functions as F
from pyspark.sql.types import *
from datetime import datetime

# Force ADLS config for job context
spark.conf.set(
    f"fs.azure.account.key.stinsclmcap11.dfs.core.windows.net",
    dbutils.secrets.get("kv-insclm", "adls-account-key")
)

dbutils.widgets.text("runId", "manual_run")
RUN_ID = dbutils.widgets.get("runId")
print(f"Run ID     : {RUN_ID}")
print(f"Start time : {datetime.now()}")
print("✅ ADLS config forced")

# COMMAND ----------

def ingest_to_bronze(source_path, target_path, schema):
    print(f"\n📥 Reading: {source_path}")
    df = (spark.read
            .option("header", "true")
            .option("dateFormat", "yyyy-MM-dd")
            .schema(schema)
            .csv(source_path)
            .withColumn("_ingestion_timestamp",
                current_timestamp())
            .withColumn("_source_file",
                F.col("_metadata.file_path"))
            .withColumn("_pipeline_run_id",
                lit(RUN_ID)))

    row_count = df.count()
    print(f"   Rows read : {row_count:,}")

    df.write \
        .format("delta") \
        .mode("overwrite") \
        .option("overwriteSchema", "true") \
        .save(target_path)

    saved = spark.read.format("delta") \
        .load(target_path).count()
    print(f"✅ {target_path.split('/')[-1]} → {saved:,} rows")
    return saved

print("✅ ingest_to_bronze function ready")

# COMMAND ----------

claims_schema = StructType([
    StructField("claim_id",        StringType(),      False),
    StructField("policy_id",       StringType(),      False),
    StructField("customer_id",     StringType(),      False),
    StructField("claim_date",      DateType(),        True),
    StructField("claim_amount",    DecimalType(18,2), True),
    StructField("claim_reason",    StringType(),      True),
    StructField("document_status", StringType(),      True),
    StructField("ingestion_date",  DateType(),        True),
])

status_schema = StructType([
    StructField("status_update_id", StringType(), False),
    StructField("claim_id",         StringType(), False),
    StructField("old_status",       StringType(), True),
    StructField("new_status",       StringType(), True),
    StructField("status_date",      DateType(),   True),
    StructField("remarks",          StringType(), True),
])

policy_schema = StructType([
    StructField("policy_id",       StringType(),      False),
    StructField("customer_id",     StringType(),      False),
    StructField("policy_type",     StringType(),      True),
    StructField("coverage_amount", DecimalType(18,2), True),
    StructField("premium_amount",  DecimalType(18,2), True),
    StructField("policy_status",   StringType(),      True),
    StructField("start_date",      DateType(),        True),
    StructField("end_date",        DateType(),        True),
    StructField("last_updated",    TimestampType(),   True),
])

customer_schema = StructType([
    StructField("customer_id",   StringType(),    False),
    StructField("customer_name", StringType(),    True),
    StructField("email",         StringType(),    True),
    StructField("phone",         StringType(),    True),
    StructField("city",          StringType(),    True),
    StructField("state",         StringType(),    True),
    StructField("dob",           StringType(),    True),
    StructField("risk_category", StringType(),    True),
    StructField("last_updated",  TimestampType(), True),
])

print("✅ All schemas defined")

# COMMAND ----------

def find_file(base_path):
    try:
        items = dbutils.fs.ls(base_path)
        for item in items:
            if item.size > 0:
                print(f"   Found: {item.path}")
                return item.path
            else:
                result = find_file(item.path)
                if result:
                    return result
    except:
        pass
    return None

policy_file_path   = find_file(RAW_PATH + "/policy_master/")
customer_file_path = find_file(RAW_PATH + "/customer_master/")

print(f"\nPolicy file   : {policy_file_path}")
print(f"Customer file : {customer_file_path}")

# COMMAND ----------

print("\n" + "=" * 55)
print("STARTING BRONZE INGESTION")
print("=" * 55)

start = datetime.now()

c1 = ingest_to_bronze(
    RAW_PATH + "/claims/claims.csv",
    BRONZE_PATH + "/claims",
    claims_schema)

c2 = ingest_to_bronze(
    RAW_PATH + "/claim_status_updates/claim_status_updates.csv",
    BRONZE_PATH + "/claim_status_updates",
    status_schema)

c3 = ingest_to_bronze(
    policy_file_path,
    BRONZE_PATH + "/policy_master",
    policy_schema)

c4 = ingest_to_bronze(
    customer_file_path,
    BRONZE_PATH + "/customer_master",
    customer_schema)

end = datetime.now()

# COMMAND ----------

print("\n" + "=" * 55)
print("STARTING BRONZE INGESTION")
print("=" * 55)

start = datetime.now()

c1 = ingest_to_bronze(
    RAW_PATH + "/claims/claims.csv",
    BRONZE_PATH + "/claims",
    claims_schema)

c2 = ingest_to_bronze(
    RAW_PATH + "/claim_status_updates/claim_status_updates.csv",
    BRONZE_PATH + "/claim_status_updates",
    status_schema)

c3 = ingest_to_bronze(
    policy_file_path,
    BRONZE_PATH + "/policy_master",
    policy_schema)

c4 = ingest_to_bronze(
    customer_file_path,
    BRONZE_PATH + "/customer_master",
    customer_schema)

end = datetime.now()

# COMMAND ----------

print("\n" + "=" * 55)
print("BRONZE INGESTION SUMMARY")
print("=" * 55)
print(f"bronze/claims               : {c1:,}  (expected 2,200)")
print(f"bronze/claim_status_updates : {c2:,}  (expected 1,600)")
print(f"bronze/policy_master        : {c3:,}  (expected 1,500)")
print(f"bronze/customer_master      : {c4:,}  (expected 1,000)")
print(f"Total time                  : {end - start}")
print("=" * 55)

all_ok = (c1==2200 and c2==1600 and c3==1500 and c4==1000)
if all_ok:
    print("✅ All counts match. Bronze layer complete.")
    print("   Next: Run NB_02 Cells 1-4")
else:
    print("❌ Count mismatch — check raw zone paths")