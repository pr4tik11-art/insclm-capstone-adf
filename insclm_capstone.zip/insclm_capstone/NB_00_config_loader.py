# Databricks notebook source
dbutils.secrets.listScopes()

# COMMAND ----------

# Test secret scope
dbutils.secrets.list("kv-insclm")

# COMMAND ----------

KV_SCOPE = "kv-insclm"

# ── ADLS Configuration ───────────────────────────────────────
ADLS_ACCOUNT_NAME = dbutils.secrets.get(KV_SCOPE, "adls-account-name")
ADLS_ACCOUNT_KEY  = dbutils.secrets.get(KV_SCOPE, "adls-account-key")
ADLS_CONTAINER    = dbutils.secrets.get(KV_SCOPE, "adls-container-name")
ADLS_ABFSS_BASE   = dbutils.secrets.get(KV_SCOPE, "adls-abfss-base")

# ── Configure Spark to access ADLS ───────────────────────────
spark.conf.set(
    f"fs.azure.account.key.{ADLS_ACCOUNT_NAME}.dfs.core.windows.net",
    ADLS_ACCOUNT_KEY
)
spark.conf.set(
    "fs.azure.account.key.stinsclmcap11.dfs.core.windows.net",
    ADLS_ACCOUNT_KEY
)

# ── Zone Paths ───────────────────────────────────────────────
RAW_PATH      = ADLS_ABFSS_BASE + dbutils.secrets.get(KV_SCOPE, "adls-raw-path")
BRONZE_PATH   = ADLS_ABFSS_BASE + dbutils.secrets.get(KV_SCOPE, "adls-bronze-path")
SILVER_PATH   = ADLS_ABFSS_BASE + dbutils.secrets.get(KV_SCOPE, "adls-silver-path")
GOLD_PATH     = ADLS_ABFSS_BASE + dbutils.secrets.get(KV_SCOPE, "adls-gold-path")
REJECTED_PATH = ADLS_ABFSS_BASE + dbutils.secrets.get(KV_SCOPE, "adls-rejected-path")
AUDIT_PATH    = ADLS_ABFSS_BASE + dbutils.secrets.get(KV_SCOPE, "adls-audit-path")

# ── SQL Configuration ─────────────────────────────────────────
SQL_JDBC_URL = dbutils.secrets.get(KV_SCOPE, "sql-jdbc-url")
SQL_USER     = dbutils.secrets.get(KV_SCOPE, "sql-admin-name")
SQL_PASSWORD = dbutils.secrets.get(KV_SCOPE, "sql-admin-password")
SQL_SERVER   = dbutils.secrets.get(KV_SCOPE, "sql-server-fqdn")
SQL_DATABASE = dbutils.secrets.get(KV_SCOPE, "sql-database-name")

# ── Source File Names ─────────────────────────────────────────
FILE_CLAIMS          = dbutils.secrets.get(KV_SCOPE, "file-claims")
FILE_CLAIM_STATUS    = dbutils.secrets.get(KV_SCOPE, "file-claim-status-updates")
FILE_POLICY_MASTER   = dbutils.secrets.get(KV_SCOPE, "file-policy-master")
FILE_CUSTOMER_MASTER = dbutils.secrets.get(KV_SCOPE, "file-customer-master")

# ── Source Table Names ────────────────────────────────────────
SQL_TABLE_POLICY   = dbutils.secrets.get(KV_SCOPE, "sql-table-policy-master")
SQL_TABLE_CUSTOMER = dbutils.secrets.get(KV_SCOPE, "sql-table-customer-master")

print("=" * 55)
print("✅ Config loaded from Key Vault successfully.")
print(f"   ADLS Account  : {ADLS_ACCOUNT_NAME}")
print(f"   Container     : {ADLS_CONTAINER}")
print(f"   ABFSS Base    : {ADLS_ABFSS_BASE}")
print(f"   RAW path      : {RAW_PATH}")
print(f"   BRONZE path   : {BRONZE_PATH}")
print(f"   SILVER path   : {SILVER_PATH}")
print(f"   GOLD path     : {GOLD_PATH}")
print(f"   REJECTED path : {REJECTED_PATH}")
print(f"   AUDIT path    : {AUDIT_PATH}")
print(f"   SQL Server    : {SQL_SERVER}")
print(f"   SQL Database  : {SQL_DATABASE}")
print("=" * 55)