# Databricks notebook source
# MAGIC %run /Workspace/Users/updazvmnag_1777788725142@npupgradassessment.onmicrosoft.com/insclm_capstone/NB_00_config_loader

# COMMAND ----------

from pyspark.sql import functions as F
from delta.tables import DeltaTable

# Force ADLS config for job context
spark.conf.set(
    "fs.azure.account.key.stinsclmcap11.dfs.core.windows.net",
    dbutils.secrets.get("kv-insclm", "adls-account-key")
)

def path_exists(path):
    try:
        dbutils.fs.ls(path)
        return True
    except:
        return False

STATUS_PATH = SILVER_PATH + "/claim_status_history"
print("✅ Imports done")

# COMMAND ----------

print("\n📥 Loading bronze/claim_status_updates...")
bronze_status = spark.read.format("delta") \
    .load(BRONZE_PATH + "/claim_status_updates")
print(f"   Rows: {bronze_status.count():,}  (expected 1,600)")

source = (bronze_status
    .withColumn("is_terminal_status",
        F.col("new_status").isin("Approved","Rejected"))
    .withColumn("_silver_loaded_at",
        F.current_timestamp()))

print("\nis_terminal_status distribution:")
source.groupBy("is_terminal_status","new_status") \
    .count().orderBy("is_terminal_status").show()

# COMMAND ----------

if not path_exists(STATUS_PATH + "/_delta_log"):
    print("\n📥 Initial load...")

    source.write \
        .format("delta").mode("overwrite") \
        .option("overwriteSchema","true") \
        .save(STATUS_PATH)

    count = spark.read.format("delta") \
        .load(STATUS_PATH).count()
    print(f"✅ silver/claim_status_history → {count:,} rows")

else:
    print("\n📥 MERGE running...")
    before = spark.read.format("delta") \
        .load(STATUS_PATH).count()
    target = DeltaTable.forPath(spark, STATUS_PATH)

    (target.alias("t")
        .merge(source.alias("s"),
            "t.status_update_id = s.status_update_id")
        .whenMatchedUpdateAll()
        .whenNotMatchedInsertAll()
        .execute())

    after = spark.read.format("delta") \
        .load(STATUS_PATH).count()
    print(f"   Before : {before:,} | After : {after:,}")
    print(f"   New rows: {after - before:,}")

# COMMAND ----------

print("\n── Status Distribution ──────────────────────────────")
spark.read.format("delta").load(STATUS_PATH) \
    .groupBy("new_status").count() \
    .orderBy(F.desc("count")).show()

print("── Terminal Status ──────────────────────────────────")
spark.read.format("delta").load(STATUS_PATH) \
    .groupBy("is_terminal_status").count().show()

print("── Delta History ────────────────────────────────────")
DeltaTable.forPath(spark, STATUS_PATH) \
    .history(3) \
    .select("version","timestamp","operation") \
    .show(truncate=False)

total = spark.read.format("delta").load(STATUS_PATH).count()
print(f"\nFinal row count: {total:,}  (expected 1,600)")
print("✅ NB_05 complete.")
print("   Next: Run NB_06_gold_tables")