# Databricks notebook source
# MAGIC %run /Workspace/Users/updazvmnag_1777788725142@npupgradassessment.onmicrosoft.com/insclm_capstone/NB_00_config_loader

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window

# Force ADLS config for job context
spark.conf.set(
    "fs.azure.account.key.stinsclmcap11.dfs.core.windows.net",
    dbutils.secrets.get("kv-insclm", "adls-account-key")
)

print("✅ Imports done")

# COMMAND ----------

print("\n📥 Loading silver tables...")
claims_fact = spark.read.format("delta") \
    .load(SILVER_PATH + "/claims_fact")
policy_dim  = spark.read.format("delta") \
    .load(SILVER_PATH + "/policy_dim")
status_hist = spark.read.format("delta") \
    .load(SILVER_PATH + "/claim_status_history")

print(f"   claims_fact    : {claims_fact.count():,}")
print(f"   policy_dim     : {policy_dim.count():,}")
print(f"   status_history : {status_hist.count():,}")

print("\npolicy_type distribution:")
claims_fact.groupBy("policy_type") \
    .count().orderBy(F.desc("count")).show()

# COMMAND ----------

status_window = Window.partitionBy("claim_id") \
    .orderBy(F.desc("status_date"))

latest_status = (status_hist
    .withColumn("rn", F.row_number().over(status_window))
    .filter(F.col("rn") == 1)
    .select(
        "claim_id",
        F.col("new_status").alias("final_status"),
        F.col("status_date").alias("final_status_date"),
        F.col("remarks").alias("final_remarks"),
        "is_terminal_status"))

claims_with_status = claims_fact.join(
    latest_status, "claim_id", "left")

print(f"✅ Latest status joined: {claims_with_status.count():,}")

# COMMAND ----------

print("\n📥 Building gold/claim_summary...")

gold_claim_summary = (claims_with_status
    .groupBy("policy_type","claim_reason")
    .agg(
        F.count("claim_id")
         .alias("total_claims"),
        F.sum(F.when(F.col("final_status")=="Approved",1)
              .otherwise(0))
         .alias("approved_claims"),
        F.sum(F.when(F.col("final_status")=="Rejected",1)
              .otherwise(0))
         .alias("rejected_claims"),
        F.sum(F.when(F.col("final_status")=="Pending",1)
              .otherwise(0))
         .alias("pending_claims"),
        F.sum(F.when(F.col("final_status")=="Investigation",1)
              .otherwise(0))
         .alias("investigation_claims"),
        F.round(F.sum("claim_amount"),2)
         .alias("total_claim_amount"),
        F.round(F.avg("claim_amount"),2)
         .alias("avg_claim_amount"),
        F.round(F.min("claim_amount"),2)
         .alias("min_claim_amount"),
        F.round(F.max("claim_amount"),2)
         .alias("max_claim_amount"),
    )
    .withColumn("approval_rate_pct",
        F.round(F.col("approved_claims") /
                F.col("total_claims") * 100, 2))
    .withColumn("rejection_rate_pct",
        F.round(F.col("rejected_claims") /
                F.col("total_claims") * 100, 2))
    .withColumn("_gold_loaded_at", F.current_timestamp()))

gold_claim_summary.write \
    .format("delta").mode("overwrite") \
    .option("overwriteSchema","true") \
    .save(GOLD_PATH + "/claim_summary")

g1 = spark.read.format("delta") \
    .load(GOLD_PATH + "/claim_summary").count()
print(f"✅ gold/claim_summary → {g1:,} rows")

print("\nPreview — top 5:")
spark.read.format("delta") \
    .load(GOLD_PATH + "/claim_summary") \
    .orderBy(F.desc("total_claims")) \
    .select("policy_type","claim_reason","total_claims",
            "approved_claims","rejected_claims",
            "approval_rate_pct","rejection_rate_pct") \
    .show(5, truncate=False)

# COMMAND ----------

print("\n📥 Building gold/policy_history_summary...")

policy_agg = (policy_dim
    .groupBy("policy_id","customer_id")
    .agg(
        F.count("*")
         .alias("total_versions"),
        F.min("effective_date")
         .alias("first_effective_date"),
        F.max(F.when(F.col("is_current")==True,
                     F.col("policy_status")))
         .alias("current_policy_status"),
        F.max(F.when(F.col("is_current")==True,
                     F.col("coverage_amount")))
         .alias("current_coverage"),
        F.max(F.when(F.col("is_current")==True,
                     F.col("premium_amount")))
         .alias("current_premium"),
        F.max(F.when(F.col("is_current")==True,
                     F.col("policy_type")))
         .alias("current_policy_type"),
        F.min(F.when(F.col("is_current")==False,
                     F.col("coverage_amount")))
         .alias("original_coverage"),
    ))

claims_agg = (claims_fact
    .groupBy("policy_id")
    .agg(
        F.count("claim_id")
         .alias("total_claims_against_policy"),
        F.round(F.sum("claim_amount"),2)
         .alias("total_claim_amount_against_policy"),
    ))

gold_policy_history = (policy_agg
    .join(claims_agg,"policy_id","left")
    .fillna(0,["total_claims_against_policy",
               "total_claim_amount_against_policy"])
    .withColumn("coverage_change_pct",
        F.when(
            F.col("original_coverage").isNotNull() &
            (F.col("original_coverage") > 0),
            F.round(
                (F.col("current_coverage") -
                 F.col("original_coverage")) /
                F.col("original_coverage") * 100, 2))
        .otherwise(F.lit(0.0)))
    .withColumn("_gold_loaded_at", F.current_timestamp()))

gold_policy_history.write \
    .format("delta").mode("overwrite") \
    .option("overwriteSchema","true") \
    .save(GOLD_PATH + "/policy_history_summary")

g2 = spark.read.format("delta") \
    .load(GOLD_PATH + "/policy_history_summary").count()
print(f"✅ gold/policy_history_summary → {g2:,} rows")

# COMMAND ----------

print("\n📥 Building gold/suspicious_claim_summary...")

gold_suspicious = (claims_fact
    .filter(F.col("suspicious_score") >= 1)
    .withColumn("suspicion_level",
        F.when(F.col("suspicious_score")==1,"LOW")
        .when(F.col("suspicious_score")==2,"MEDIUM")
        .otherwise("HIGH"))
    .join(latest_status.select(
              "claim_id","final_status",
              "final_status_date","final_remarks"),
          "claim_id","left")
    .select(
        "claim_id","policy_id","customer_id",
        "customer_name","state","risk_category",
        "claim_amount","coverage_amount",
        "policy_status_at_claim","document_status",
        "claim_reason","claim_date",
        "customer_claim_count",
        "amount_exceeds_coverage_flag",
        "inactive_policy_flag",
        "incomplete_docs_flag",
        "high_frequency_flag",
        "suspicious_score","suspicion_level",
        "final_status","final_status_date",
        "final_remarks")
    .withColumn("_gold_loaded_at", F.current_timestamp()))

gold_suspicious.write \
    .format("delta").mode("overwrite") \
    .option("overwriteSchema","true") \
    .save(GOLD_PATH + "/suspicious_claim_summary")

g3 = spark.read.format("delta") \
    .load(GOLD_PATH + "/suspicious_claim_summary").count()
print(f"✅ gold/suspicious_claim_summary → {g3:,} rows")

print("\nSuspicion level breakdown:")
spark.read.format("delta") \
    .load(GOLD_PATH + "/suspicious_claim_summary") \
    .groupBy("suspicion_level").count() \
    .orderBy("suspicion_level").show()

# COMMAND ----------

print("\n" + "=" * 55)
print("GOLD LAYER SUMMARY")
print("=" * 55)
print(f"gold/claim_summary            : {g1:,} rows")
print(f"gold/policy_history_summary   : {g2:,} rows")
print(f"gold/suspicious_claim_summary : {g3:,} rows")
print("=" * 55)
print("✅ NB_06 complete.")
print("   Next: Run NB_07_time_travel_demo")