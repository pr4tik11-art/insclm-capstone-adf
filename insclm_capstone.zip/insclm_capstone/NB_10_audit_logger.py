# Databricks notebook source
# MAGIC %run /Workspace/Users/updazvmnag_1777788725142@npupgradassessment.onmicrosoft.com/insclm_capstone/NB_00_config_loader

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType, StructField,
    StringType, LongType, TimestampType)
from datetime import datetime

# Force ADLS config for job context
spark.conf.set(
    "fs.azure.account.key.stinsclmcap11.dfs.core.windows.net",
    dbutils.secrets.get("kv-insclm", "adls-account-key")
)

print("=" * 55)
print("AUDIT PIPELINE LOG")
print("=" * 55)

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType, StructField,
    StringType, LongType, TimestampType)
from datetime import datetime

print("=" * 55)
print("AUDIT PIPELINE LOG")
print("=" * 55)

# COMMAND ----------

AUDIT_TABLE_PATH = AUDIT_PATH + "/pipeline_log"

audit_schema = StructType([
    StructField("run_id",           StringType(),    False),
    StructField("pipeline_name",    StringType(),    False),
    StructField("source_name",      StringType(),    True),
    StructField("target_name",      StringType(),    True),
    StructField("load_type",        StringType(),    True),
    StructField("start_time",       TimestampType(), True),
    StructField("end_time",         TimestampType(), True),
    StructField("records_read",     LongType(),      True),
    StructField("records_inserted", LongType(),      True),
    StructField("records_updated",  LongType(),      True),
    StructField("records_rejected", LongType(),      True),
    StructField("status",           StringType(),    True),
    StructField("error_message",    StringType(),    True),
    StructField("notes",            StringType(),    True),
])

def path_exists(path):
    try:
        dbutils.fs.ls(path)
        return True
    except:
        return False

if not path_exists(AUDIT_TABLE_PATH + "/_delta_log"):
    (spark.createDataFrame([], audit_schema)
        .write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .save(AUDIT_TABLE_PATH))
    print("✅ audit/pipeline_log table created")
else:
    print("✅ audit/pipeline_log already exists")

# COMMAND ----------

def log_audit(run_id, pipeline_name, source_name,
              target_name, load_type,
              start_time=None, end_time=None,
              records_read=0, records_inserted=0,
              records_updated=0, records_rejected=0,
              status="SUCCESS", error_message=None,
              notes=None):

    row = [(
        run_id,
        pipeline_name,
        source_name,
        target_name,
        load_type,
        start_time,
        end_time,
        records_read,
        records_inserted,
        records_updated,
        records_rejected,
        status,
        error_message,
        notes,
    )]

    df = spark.createDataFrame(row, audit_schema)
    df.write \
        .format("delta") \
        .mode("append") \
        .save(AUDIT_TABLE_PATH)

print("✅ log_audit function ready")

# COMMAND ----------

print("\n📥 Reading row counts from all tables...")

def safe_count(path):
    try:
        return spark.read.format("delta").load(path).count()
    except:
        return 0

counts = {
    "bronze_claims":
        safe_count(BRONZE_PATH + "/claims"),
    "bronze_claim_status_updates":
        safe_count(BRONZE_PATH + "/claim_status_updates"),
    "bronze_policy_master":
        safe_count(BRONZE_PATH + "/policy_master"),
    "bronze_customer_master":
        safe_count(BRONZE_PATH + "/customer_master"),
    "silver_customer_dim":
        safe_count(SILVER_PATH + "/customer_dim"),
    "silver_claims_fact":
        safe_count(SILVER_PATH + "/claims_fact"),
    "silver_policy_dim":
        safe_count(SILVER_PATH + "/policy_dim"),
    "silver_claim_status_history":
        safe_count(SILVER_PATH + "/claim_status_history"),
    "rejected_claims":
        safe_count(REJECTED_PATH + "/claims"),
    "rejected_status_updates":
        safe_count(REJECTED_PATH + "/status_updates"),
    "rejected_policy":
        safe_count(REJECTED_PATH + "/policy"),
    "rejected_customers":
        safe_count(REJECTED_PATH + "/customers"),
    "gold_claim_summary":
        safe_count(GOLD_PATH + "/claim_summary"),
    "gold_policy_history_summary":
        safe_count(GOLD_PATH + "/policy_history_summary"),
    "gold_suspicious_claim_summary":
        safe_count(GOLD_PATH + "/suspicious_claim_summary"),
}

for table, count in counts.items():
    print(f"   {table:<40}: {count:,}")

# COMMAND ----------

print("\n📥 Logging all pipeline stages...")

RUN_ID = f"CAPSTONE06_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
print(f"   Batch Run ID: {RUN_ID}\n")

audit_entries = [
    ("NB_01_bronze_ingestion",
     "raw/claims/claims.csv",
     "lakehouse/bronze/claims",
     "FULL_LOAD",
     counts["bronze_claims"],
     counts["bronze_claims"],
     0, 0, "SUCCESS", None,
     "Initial ingestion from claims.csv"),

    ("NB_01_bronze_ingestion",
     "raw/claim_status_updates/",
     "lakehouse/bronze/claim_status_updates",
     "FULL_LOAD",
     counts["bronze_claim_status_updates"],
     counts["bronze_claim_status_updates"],
     0, 0, "SUCCESS", None,
     "Initial ingestion from claim_status_updates.csv"),

    ("NB_01_bronze_ingestion",
     "raw/policy_master/",
     "lakehouse/bronze/policy_master",
     "FULL_LOAD",
     counts["bronze_policy_master"],
     counts["bronze_policy_master"],
     0, 0, "SUCCESS", None,
     "Ingested from ADF dated folder"),

    ("NB_01_bronze_ingestion",
     "raw/customer_master/",
     "lakehouse/bronze/customer_master",
     "FULL_LOAD",
     counts["bronze_customer_master"],
     counts["bronze_customer_master"],
     0, 0, "SUCCESS", None,
     "Ingested from ADF dated folder"),

    ("NB_02_silver_transformation",
     "lakehouse/bronze/customer_master",
     "lakehouse/silver/customer_dim",
     "FULL_LOAD",
     counts["bronze_customer_master"],
     counts["silver_customer_dim"],
     0, 0, "SUCCESS", None,
     "Cleaned + age_years + email_valid + phone_valid"),

    ("NB_02_silver_transformation",
     "lakehouse/bronze/claims",
     "lakehouse/rejected/claims",
     "FULL_LOAD",
     counts["bronze_claims"],
     counts["rejected_claims"],
     0, counts["rejected_claims"],
     "SUCCESS", None,
     "Rejected: MISSING_DOCUMENT_STATUS"),

    ("NB_02_silver_transformation",
     "bronze + policy_dim + customer_dim",
     "lakehouse/silver/claims_fact",
     "FULL_LOAD",
     counts["bronze_claims"] - counts["rejected_claims"],
     counts["silver_claims_fact"],
     0, counts["rejected_claims"],
     "SUCCESS", None,
     "3-way join + 4 flags + suspicious_score"),

    ("NB_03_silver_rejected_records",
     "lakehouse/bronze/claim_status_updates",
     "lakehouse/rejected/status_updates",
     "FULL_LOAD",
     counts["bronze_claim_status_updates"],
     counts["rejected_status_updates"],
     0, counts["rejected_status_updates"],
     "SUCCESS", None,
     "0 rejections — data is clean"),

    ("NB_03_silver_rejected_records",
     "lakehouse/bronze/policy_master",
     "lakehouse/rejected/policy",
     "FULL_LOAD",
     counts["bronze_policy_master"],
     counts["rejected_policy"],
     0, counts["rejected_policy"],
     "SUCCESS", None,
     "0 rejections — data is clean"),

    ("NB_03_silver_rejected_records",
     "lakehouse/bronze/customer_master",
     "lakehouse/rejected/customers",
     "FULL_LOAD",
     counts["bronze_customer_master"],
     counts["rejected_customers"],
     0, 0,
     "SUCCESS", None,
     "0 rejections — data is clean"),

    ("NB_04_scd_policy_dim",
     "lakehouse/bronze/policy_master",
     "lakehouse/silver/policy_dim",
     "SCD_TYPE2",
     counts["bronze_policy_master"],
     counts["silver_policy_dim"],
     0, 0, "SUCCESS", None,
     "SCD Type 2 — effective/expiry/is_current/hash"),

    ("NB_05_merge_claim_status",
     "lakehouse/bronze/claim_status_updates",
     "lakehouse/silver/claim_status_history",
     "DELTA_MERGE",
     counts["bronze_claim_status_updates"],
     counts["silver_claim_status_history"],
     0, 0, "SUCCESS", None,
     "Delta MERGE upsert on status_update_id"),

    ("NB_06_gold_tables",
     "lakehouse/silver/claims_fact",
     "lakehouse/gold/claim_summary",
     "AGGREGATION",
     counts["silver_claims_fact"],
     counts["gold_claim_summary"],
     0, 0, "SUCCESS", None,
     "Grouped by policy_type + claim_reason"),

    ("NB_06_gold_tables",
     "lakehouse/silver/policy_dim",
     "lakehouse/gold/policy_history_summary",
     "AGGREGATION",
     counts["silver_policy_dim"],
     counts["gold_policy_history_summary"],
     0, 0, "SUCCESS", None,
     "Policy version history + coverage_change_pct"),

    ("NB_06_gold_tables",
     "lakehouse/silver/claims_fact",
     "lakehouse/gold/suspicious_claim_summary",
     "FILTER",
     counts["silver_claims_fact"],
     counts["gold_suspicious_claim_summary"],
     0, 0, "SUCCESS", None,
     "Filtered suspicious_score >= 1"),

    ("NB_09_load_to_azure_sql",
     "lakehouse/gold/claim_summary",
     "reporting.fact_claim_summary",
     "JDBC_WRITE",
     counts["gold_claim_summary"],
     counts["gold_claim_summary"],
     0, 0, "SUCCESS", None,
     "Written to Azure SQL via JDBC"),

    ("NB_09_load_to_azure_sql",
     "lakehouse/gold/suspicious_claim_summary",
     "reporting.fact_suspicious_claims",
     "JDBC_WRITE",
     counts["gold_suspicious_claim_summary"],
     counts["gold_suspicious_claim_summary"],
     0, 0, "SUCCESS", None,
     "Written to Azure SQL via JDBC"),

    ("NB_09_load_to_azure_sql",
     "lakehouse/silver/policy_dim",
     "reporting.dim_policy_history",
     "JDBC_WRITE",
     counts["silver_policy_dim"],
     counts["silver_policy_dim"],
     0, 0, "SUCCESS", None,
     "Written to Azure SQL via JDBC"),
]

for entry in audit_entries:
    log_audit(
        run_id           = RUN_ID,
        pipeline_name    = entry[0],
        source_name      = entry[1],
        target_name      = entry[2],
        load_type        = entry[3],
        start_time       = datetime.now(),
        end_time         = datetime.now(),
        records_read     = entry[4],
        records_inserted = entry[5],
        records_updated  = entry[6],
        records_rejected = entry[7],
        status           = entry[8],
        error_message    = entry[9],
        notes            = entry[10]
    )
    print(f"✅ Logged: {entry[2]}")

# COMMAND ----------

print("\n" + "=" * 55)
print("FULL AUDIT LOG")
print("=" * 55)

spark.read.format("delta") \
    .load(AUDIT_TABLE_PATH) \
    .select(
        "pipeline_name",
        "source_name",
        "target_name",
        "load_type",
        "records_read",
        "records_inserted",
        "records_rejected",
        "status"
    ).show(20, truncate=False)

# COMMAND ----------

audit_df = spark.read.format("delta") \
    .load(AUDIT_TABLE_PATH)

total_logged   = audit_df.count()
total_read     = audit_df.agg(
    F.sum("records_read")).first()[0] or 0
total_inserted = audit_df.agg(
    F.sum("records_inserted")).first()[0] or 0
total_rejected = audit_df.agg(
    F.sum("records_rejected")).first()[0] or 0

print("\n" + "=" * 55)
print("AUDIT SUMMARY")
print("=" * 55)
print(f"Run ID              : {RUN_ID}")
print(f"Total stages logged : {total_logged:,}")
print(f"Total records read  : {total_read:,}")
print(f"Total records saved : {total_inserted:,}")
print(f"Total records reject: {total_rejected:,}")
print("=" * 55)
print("✅ NB_10 complete.")
print("✅ ALL NOTEBOOKS DONE!")
print("\nFinal steps:")
print("1. Check ADLS lakehouse container")
print("2. Take screenshots")
print("3. Export notebooks to GitHub")
print("=" * 55)

# COMMAND ----------


print("=" * 55)
print("ADLS LAKEHOUSE FOLDER STRUCTURE")
print("=" * 55)

zones = {
    "raw"     : RAW_PATH,
    "bronze"  : BRONZE_PATH,
    "silver"  : SILVER_PATH,
    "gold"    : GOLD_PATH,
    "rejected": REJECTED_PATH,
    "audit"   : AUDIT_PATH,
}

for zone, path in zones.items():
    try:
        items = dbutils.fs.ls(path)
        folders = [i.name for i in items]
        print(f"\n✅ lakehouse/{zone}/")
        for f in folders:
            print(f"   └── {f}")
    except Exception as e:
        print(f"\n❌ lakehouse/{zone}/ → {e}")

# COMMAND ----------

paths_to_clean = [
    BRONZE_PATH   + "/claims",
    BRONZE_PATH   + "/claim_status_updates",
    BRONZE_PATH   + "/policy_master",
    BRONZE_PATH   + "/customer_master",
    SILVER_PATH   + "/claims_fact",
    SILVER_PATH   + "/customer_dim",
    SILVER_PATH   + "/policy_dim",
    SILVER_PATH   + "/claim_status_history",
    GOLD_PATH     + "/claim_summary",
    GOLD_PATH     + "/policy_history_summary",
    GOLD_PATH     + "/suspicious_claim_summary",
    REJECTED_PATH + "/claims",
    REJECTED_PATH + "/status_updates",
    REJECTED_PATH + "/policy",
    REJECTED_PATH + "/customers",
    AUDIT_PATH    + "/pipeline_log",
]

for path in paths_to_clean:
    try:
        dbutils.fs.rm(path, recurse=True)
        name = path.split('/')[-2] + "/" + path.split('/')[-1]
        print(f"✅ Cleared: {name}")
    except:
        name = path.split('/')[-1]
        print(f"   Not found: {name}")

print("\n✅ All zones cleared. Ready for pipeline.")

# COMMAND ----------


paths_to_clean = [
    BRONZE_PATH + "/claims",
    BRONZE_PATH + "/claim_status_updates",
    BRONZE_PATH + "/policy_master",
    BRONZE_PATH + "/customer_master",
    SILVER_PATH + "/claims_fact",
    SILVER_PATH + "/customer_dim",
    SILVER_PATH + "/policy_dim",
    SILVER_PATH + "/claim_status_history",
    GOLD_PATH   + "/claim_summary",
    GOLD_PATH   + "/policy_history_summary",
    GOLD_PATH   + "/suspicious_claim_summary",
    REJECTED_PATH + "/claims",
    REJECTED_PATH + "/status_updates",
    REJECTED_PATH + "/policy",
    REJECTED_PATH + "/customers",
    AUDIT_PATH  + "/pipeline_log",
]

for path in paths_to_clean:
    try:
        dbutils.fs.rm(path, recurse=True)
        name = path.split('/')[-2] + "/" + path.split('/')[-1]
        print(f"✅ Cleared: {name}")
    except:
        print(f"   Not found: {path.split('/')[-1]}")

print("\n✅ Ready for pipeline run")

# COMMAND ----------

# Check all databases in Unity Catalog
spark.sql("SHOW DATABASES").show()

# COMMAND ----------

# Check tables in each database
for db in ["bronze_insclm", "silver_insclm", 
           "gold_insclm", "rejected_insclm", 
           "audit_insclm"]:
    try:
        tables = spark.sql(f"SHOW TABLES IN {db}")
        count = tables.count()
        print(f"\n{db}: {count} tables")
        tables.show(truncate=False)
    except Exception as e:
        print(f"\n{db}: not found")