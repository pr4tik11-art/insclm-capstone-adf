# Databricks notebook source
# MAGIC %run /Workspace/Users/updazvmnag_1777788725142@npupgradassessment.onmicrosoft.com/insclm_capstone/NB_00_config_loader

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.types import *
from datetime import datetime

# Force ADLS config for job context
spark.conf.set(
    "fs.azure.account.key.stinsclmcap11.dfs.core.windows.net",
    dbutils.secrets.get("kv-insclm", "adls-account-key")
)

print("✅ Imports and ADLS config done")

# COMMAND ----------

print("\n📥 Building silver/customer_dim...")
bronze_customer = spark.read.format("delta") \
    .load(BRONZE_PATH + "/customer_master")
print(f"   Bronze rows: {bronze_customer.count():,}")

silver_customer = (bronze_customer
    .withColumn("dob_parsed",
        F.coalesce(
            F.to_date(F.col("dob"),
                "yyyy-MM-dd HH:mm:ss.SSSSSSS"),
            F.to_date(F.col("dob"),
                "yyyy-MM-dd HH:mm:ss"),
            F.to_date(F.col("dob"), "yyyy-MM-dd"),
            F.to_date(F.col("dob"), "dd-MM-yyyy"),
        ))
    .withColumn("age_years",
        F.when(F.col("dob_parsed").isNotNull(),
            F.floor(F.months_between(
                F.current_date(),
                F.col("dob_parsed")) / 12))
        .otherwise(F.lit(None)))
    .withColumn("email_valid",
        F.col("email").rlike(
            r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$"))
    .withColumn("phone_valid",
        F.length(F.col("phone")) == 10)
    .withColumn("_silver_loaded_at",
        F.current_timestamp())
    .drop("dob")
    .withColumnRenamed("dob_parsed", "dob")
    .dropDuplicates(["customer_id"]))

silver_customer.write \
    .format("delta").mode("overwrite") \
    .option("overwriteSchema","true") \
    .save(SILVER_PATH + "/customer_dim")

c = spark.read.format("delta") \
    .load(SILVER_PATH + "/customer_dim").count()
print(f"✅ silver/customer_dim → {c:,} rows  (expected 1,000)")

# COMMAND ----------

print("\n📥 Applying rejection logic on claims...")
bronze_claims = spark.read.format("delta") \
    .load(BRONZE_PATH + "/claims")
print(f"   Bronze claims: {bronze_claims.count():,}")

rejected_conditions = (
    F.col("claim_id").isNull()                       |
    F.col("policy_id").isNull()                      |
    F.col("customer_id").isNull()                    |
    F.col("claim_amount").isNull()                   |
    (F.col("claim_amount") <= 0)                     |
    F.col("document_status").isNull()                |
    (F.col("document_status") == "Missing")          |
    (F.col("claim_date") > F.current_date())
)

rejected_claims = (bronze_claims
    .filter(rejected_conditions)
    .withColumn("rejection_reason",
        F.when(F.col("claim_id").isNull(),
               "MISSING_CLAIM_ID")
        .when(F.col("policy_id").isNull(),
               "ORPHAN_POLICY_ID")
        .when(F.col("customer_id").isNull(),
               "ORPHAN_CUSTOMER_ID")
        .when(F.col("claim_amount").isNull(),
               "MISSING_CLAIM_AMOUNT")
        .when(F.col("claim_amount") <= 0,
               "NEGATIVE_CLAIM_AMOUNT")
        .when(F.col("document_status") == "Missing",
               "MISSING_DOCUMENT_STATUS")
        .when(F.col("claim_date") > F.current_date(),
               "FUTURE_CLAIM_DATE")
        .otherwise("UNKNOWN"))
    .withColumn("rejected_at", F.current_timestamp()))

good_claims = bronze_claims.filter(~rejected_conditions)

rejected_claims.write \
    .format("delta").mode("overwrite") \
    .option("overwriteSchema","true") \
    .save(REJECTED_PATH + "/claims")

print(f"✅ rejected/claims  → {rejected_claims.count():,}")
print(f"✅ good_claims      → {good_claims.count():,}")

# COMMAND ----------

print("\n📥 Loading silver/policy_dim and customer_dim...")
policy_dim   = spark.read.format("delta") \
    .load(SILVER_PATH + "/policy_dim")
customer_dim = spark.read.format("delta") \
    .load(SILVER_PATH + "/customer_dim")

print(f"   policy_dim   : {policy_dim.count():,}")
print(f"   customer_dim : {customer_dim.count():,}")

claims_with_policy = (good_claims.alias("c")
    .join(
        policy_dim.filter(
            F.col("is_current")==True).alias("p"),
        F.col("c.policy_id") == F.col("p.policy_id"),
        "left"))

claims_with_all = (claims_with_policy
    .join(customer_dim.alias("cu"),
          F.col("c.customer_id") ==
          F.col("cu.customer_id"), "left"))

print(f"✅ Joined rows: {claims_with_all.count():,}")

# COMMAND ----------

customer_window = Window.partitionBy("c.customer_id")

silver_claims_fact = (claims_with_all
    .withColumn("customer_claim_count",
        F.count("c.claim_id").over(customer_window))
    .withColumn("amount_exceeds_coverage_flag",
        F.when(F.col("c.claim_amount") >
               F.col("p.coverage_amount"), True)
        .otherwise(False))
    .withColumn("inactive_policy_flag",
        F.col("p.policy_status")
        .isin("Cancelled","Lapsed","Expired"))
    .withColumn("incomplete_docs_flag",
        F.col("c.document_status")
        .isin("Incomplete","Missing"))
    .withColumn("high_frequency_flag",
        F.col("customer_claim_count") > 5)
    .withColumn("suspicious_score",
        F.col("amount_exceeds_coverage_flag").cast("int") +
        F.col("inactive_policy_flag").cast("int") +
        F.col("incomplete_docs_flag").cast("int") +
        F.col("high_frequency_flag").cast("int"))
    .withColumn("_silver_loaded_at",
        F.current_timestamp())
    .select(
        F.col("c.claim_id"),
        F.col("c.policy_id"),
        F.col("p.policy_sk"),
        F.col("c.customer_id"),
        F.col("cu.customer_name"),
        F.col("cu.city"),
        F.col("cu.state"),
        F.col("cu.risk_category"),
        F.col("p.policy_type"),
        F.col("p.coverage_amount"),
        F.col("p.premium_amount"),
        F.col("p.policy_status").alias(
            "policy_status_at_claim"),
        F.col("c.claim_date"),
        F.col("c.claim_amount"),
        F.col("c.claim_reason"),
        F.col("c.document_status"),
        "amount_exceeds_coverage_flag",
        "inactive_policy_flag",
        "incomplete_docs_flag",
        "high_frequency_flag",
        "customer_claim_count",
        "suspicious_score",
        F.col("c.ingestion_date"),
        "_silver_loaded_at"
    ))

print(f"✅ silver_claims_fact: {silver_claims_fact.count():,}")

# COMMAND ----------

silver_claims_fact.write \
    .format("delta").mode("overwrite") \
    .option("overwriteSchema","true") \
    .save(SILVER_PATH + "/claims_fact")

count = spark.read.format("delta") \
    .load(SILVER_PATH + "/claims_fact").count()
print(f"✅ silver/claims_fact → {count:,} rows")

print("\n── Business Flag Summary ─────────────────────────────")
spark.read.format("delta") \
    .load(SILVER_PATH + "/claims_fact").agg(
    F.count("claim_id").alias("total_claims"),
    F.sum(F.col("amount_exceeds_coverage_flag")
          .cast("int")).alias("exceeds_coverage"),
    F.sum(F.col("inactive_policy_flag")
          .cast("int")).alias("inactive_policy"),
    F.sum(F.col("incomplete_docs_flag")
          .cast("int")).alias("incomplete_docs"),
    F.sum(F.col("high_frequency_flag")
          .cast("int")).alias("high_frequency"),
).show()

print("✅ NB_02 complete.")