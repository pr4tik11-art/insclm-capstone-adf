# Databricks notebook source
# MAGIC %run /Workspace/Users/updazvmnag_1777788725142@npupgradassessment.onmicrosoft.com/insclm_capstone/NB_00_config_loader

# COMMAND ----------

paths_to_clean = [
    BRONZE_PATH + "/claims",
    BRONZE_PATH + "/claim_status_updates",
    BRONZE_PATH + "/policy_master",
    BRONZE_PATH + "/customer_master",
    SILVER_PATH + "/claims_fact",
    SILVER_PATH + "/customer_dim",
    SILVER_PATH + "/policy_dim",
    SILVER_PATH + "/claim_status_history",
    GOLD_PATH   + "/claim_summary",
    GOLD_PATH   + "/policy_history_summary",
    GOLD_PATH   + "/suspicious_claim_summary",
    REJECTED_PATH + "/claims",
    REJECTED_PATH + "/status_updates",
    REJECTED_PATH + "/policy",
    REJECTED_PATH + "/customers",
    AUDIT_PATH  + "/pipeline_log",
]
for path in paths_to_clean:
    try:
        dbutils.fs.rm(path, recurse=True)
        print(f"✅ Cleared: {path.split('/')[-1]}")
    except:
        print(f"   Not found: {path.split('/')[-1]}")
print("\n✅ Ready for pipeline run")

# COMMAND ----------

# ── Cell 3 — Drop databases ───────────────────────────────────
for db in ["bronze_insclm","silver_insclm","gold_insclm",
           "rejected_insclm","audit_insclm"]:
    spark.sql(f"DROP DATABASE IF EXISTS {db}")
    print(f"✅ Dropped database {db}")

# COMMAND ----------

# ── Cell 4 — Clean duplicate raw zone files ───────────────────
for folder in ["claims","claim_status_updates",
               "policy_master","customer_master"]:
    try:
        dbutils.fs.rm(RAW_PATH + f"/{folder}/2026/",
                      recurse=True)
        print(f"✅ Cleaned raw/{folder}/2026/")
    except:
        print(f"   raw/{folder}/2026/ not found — skipping")

print("\n✅ Cleanup complete!")

# COMMAND ----------

# Deep check — look inside 2026 subfolders
print("=== DEEP RAW ZONE CHECK ===")

def list_recursive(path, depth=0):
    try:
        files = dbutils.fs.ls(path)
        for f in files:
            print("  " * depth + f.name + 
                  f"  ({f.size} bytes)")
            if f.size == 0:
                list_recursive(f.path, depth+1)
    except:
        pass

print("\npolicy_master:")
list_recursive(RAW_PATH + "/policy_master/")

print("\ncustomer_master:")
list_recursive(RAW_PATH + "/customer_master/")